import { useState } from "react";
import api from "../api/api";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleLogin = async () => {
  try {
    const res = await api.post("/auth/login", {
      username,
      password,
    });

    login(
      {
        username: res.data.username,
        roles: res.data.roles,
      },
      res.data.token
    );

    navigate("/dashboard");
  } catch {
    alert("Invalid credentials");
  }
};


  return (
    <div className="center">
      <h2>PolicyPulse Login</h2>
      <input placeholder="Username" onChange={e => setUsername(e.target.value)} />
      <input type="password" placeholder="Password" onChange={e => setPassword(e.target.value)} />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}
