import React, { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import api from "../api/api";

function Dashboard() {
  const [policies, setPolicies] = useState([]);

  useEffect(() => {
    api.get("/policies")
      .then(res => setPolicies(res.data))
      .catch(err => console.error(err));
  }, []);

  return (
    <>
      <Navbar />
      <div style={{ padding: "20px" }}>
        <h2>Dashboard</h2>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))", gap: "20px" }}>
          {policies.map(p => (
            <div key={p.id} style={{ background: "#fff", padding: "15px", borderRadius: "8px" }}>
              <h3>{p.title}</h3>
              <p>Status: {p.status}</p>
              <p>Department: {p.department.name}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Dashboard;
