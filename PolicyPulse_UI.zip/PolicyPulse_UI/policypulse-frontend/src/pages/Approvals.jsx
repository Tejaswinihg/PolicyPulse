import React from "react";

function Approvals() {
  return (
    <div style={{ padding: "20px" }}>
      <h2>Approvals</h2>
      <p>Approval history and pending approvals will appear here.</p>
    </div>
  );
}

export default Approvals;
