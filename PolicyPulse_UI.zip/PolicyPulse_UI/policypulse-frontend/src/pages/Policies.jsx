import { useEffect, useState } from "react";
import api from "../api/api";
import PolicyCard from "../components/PolicyCard";

export default function Policies() {
  const [policies, setPolicies] = useState([]);

  useEffect(() => {
    api.get("/policies")
      .then(res => setPolicies(res.data))
      .catch(() => alert("Failed to load policies"));
  }, []);

  return (
    <div className="grid">
      {policies.map(p => <PolicyCard key={p.id} policy={p} />)}
    </div>
  );
}
