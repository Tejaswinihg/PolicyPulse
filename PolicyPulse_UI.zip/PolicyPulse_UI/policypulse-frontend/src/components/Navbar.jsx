import { useAuth } from "../auth/AuthContext";

function Navbar() {
  const { user, logout } = useAuth();

  return (
    <div
      style={{
        background: "#1e293b",
        color: "white",
        padding: "16px 24px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}
    >
      <h2 style={{ fontSize: "22px" }}>PolicyPulse</h2>

      {user && (
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <span style={{ fontSize: "16px" }}>
            Welcome, <b>{user.username}</b>
          </span>
          <button onClick={logout}>Logout</button>
        </div>
      )}
    </div>
  );
}

export default Navbar;
