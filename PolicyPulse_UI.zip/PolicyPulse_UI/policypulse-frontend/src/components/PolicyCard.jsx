export default function PolicyCard({ policy }) {
  return (
    <div className="card">
      <h3>{policy.title}</h3>
      <p>Status: {policy.status}</p>
      <p>Department: {policy.department.name}</p>
    </div>
  );
}
