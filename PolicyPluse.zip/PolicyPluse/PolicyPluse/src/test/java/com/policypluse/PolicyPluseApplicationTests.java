package com.policypluse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyPluseApplicationTests {

	@Test
	void contextLoads() {
	}

}
