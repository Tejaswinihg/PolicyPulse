package com.policypulse.controller;

import com.policypulse.dto.ApprovalRequest;
import com.policypulse.dto.PolicyCreateRequest;
import com.policypulse.entity.Policy;
import com.policypulse.service.PolicyService;
import org.springframework.security.access.prepost.PreAuthorize;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import com.policypulse.dto.ApprovalHistoryResponse;
import org.springframework.security.access.prepost.PreAuthorize;


@RestController
@RequestMapping("/policies")
public class PolicyController {

    private final PolicyService policyService;

    public PolicyController(PolicyService policyService) {
        this.policyService = policyService;
    }

    // ================= CREATE POLICY =================
    @PreAuthorize("hasRole('ADMIN','POLICY_OWNER')")
    @PostMapping
    public Policy createPolicy(
            @RequestBody PolicyCreateRequest request,
            Authentication authentication
    ) {
        return policyService.createPolicy(request, authentication.getName());
    }
    
    @GetMapping
    public List<Policy> getAllPolicies() {
        return policyService.getAllPolicies();
    }

    // ================= SUBMIT FOR REVIEW =================
    @PreAuthorize("hasRole('ADMIN','POLICY_OWNER')")
    @PostMapping("/{id}/submit")
    public Policy submitForReview(@PathVariable Long id) {
        return policyService.submitForReview(id);
    }

    // ================= APPROVE POLICY =================
    @PreAuthorize("hasRole('ADMIN','APPROVER')")
    @PostMapping("/{id}/approve")
    public Policy approvePolicy(
            @PathVariable Long id,
            @RequestBody ApprovalRequest request,
            Authentication auth
    ) {
        return policyService.approvePolicy(id, request, auth.getName());
    }

    // ================= REJECT POLICY =================
    @PreAuthorize("hasRole('ADMIN','APPROVER')")
    @PostMapping("/{id}/reject")
    public Policy rejectPolicy(
            @PathVariable Long id,
            @RequestBody ApprovalRequest request,
            Authentication auth
    ) {
        return policyService.rejectPolicy(id, request, auth.getName());
    }
    @PreAuthorize("hasAnyRole('ADMIN','APPROVER','POLICY_OWNER','EMPLOYEE')")
    @GetMapping("/{id}/approvals")
    public List<ApprovalHistoryResponse> getApprovalHistory(@PathVariable Long id) {
        return policyService.getApprovalHistory(id);
    }

}
