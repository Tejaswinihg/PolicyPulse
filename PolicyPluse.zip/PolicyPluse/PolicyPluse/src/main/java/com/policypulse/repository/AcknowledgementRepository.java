package com.policypulse.repository;

import com.policypulse.entity.Acknowledgement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AcknowledgementRepository extends JpaRepository<Acknowledgement, Long> {

    boolean existsByPolicyIdAndEmployeeId(Long policyId, Long employeeId);
}
