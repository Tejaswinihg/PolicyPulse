package com.policypulse.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "approvals")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Approval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "policy_version_id")
    private PolicyVersion policyVersion;

    @ManyToOne
    @JoinColumn(name = "approver_id")
    private User approver;

    @Enumerated(EnumType.STRING)
    private ApprovalDecision decision;

    private String comment;
    private LocalDateTime decisionAt;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public PolicyVersion getPolicyVersion() {
		return policyVersion;
	}
	public void setPolicyVersion(PolicyVersion policyVersion) {
		this.policyVersion = policyVersion;
	}
	public User getApprover() {
		return approver;
	}
	public void setApprover(User approver) {
		this.approver = approver;
	}
	public ApprovalDecision getDecision() {
		return decision;
	}
	public void setDecision(ApprovalDecision decision) {
		this.decision = decision;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public LocalDateTime getDecisionAt() {
		return decisionAt;
	}
	public void setDecisionAt(LocalDateTime decisionAt) {
		this.decisionAt = decisionAt;
	}
}
