package com.policypulse.repository;

import com.policypulse.entity.Approval;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ApprovalRepository extends JpaRepository<Approval, Long> {

    List<Approval> findByPolicyVersion_Policy_IdOrderByDecisionAtDesc(Long policyId);
}
