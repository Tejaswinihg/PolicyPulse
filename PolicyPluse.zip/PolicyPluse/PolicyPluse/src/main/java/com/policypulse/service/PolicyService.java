package com.policypulse.service;

import com.policypulse.dto.ApprovalRequest;
import com.policypulse.dto.PolicyCreateRequest;
import com.policypulse.entity.*;
import com.policypulse.repository.*;
import org.springframework.stereotype.Service;
import com.policypulse.dto.ApprovalHistoryResponse;
import java.util.List;
import java.util.stream.Collectors;
import java.time.LocalDateTime;

@Service
public class PolicyService {

    private final PolicyRepository policyRepo;
    private final PolicyVersionRepository versionRepo;
    private final UserRepository userRepo;
    private final DepartmentRepository deptRepo;
    private final ApprovalRepository approvalRepo;

    public PolicyService(
            PolicyRepository policyRepo,
            PolicyVersionRepository versionRepo,
            UserRepository userRepo,
            DepartmentRepository deptRepo,
            ApprovalRepository approvalRepo
    ) {
        this.policyRepo = policyRepo;
        this.versionRepo = versionRepo;
        this.userRepo = userRepo;
        this.deptRepo = deptRepo;
        this.approvalRepo = approvalRepo;
    }

    // ================= CREATE POLICY =================
    public Policy createPolicy(PolicyCreateRequest request, String username) {

        User owner = userRepo.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Logged-in user not found"));

        Department dept = deptRepo.findById(request.getDepartmentId())
                .orElseThrow(() -> new RuntimeException("Department not found"));

        Policy policy = new Policy();
        policy.setTitle(request.getTitle());
        policy.setOwner(owner);
        policy.setDepartment(dept);
        policy.setStatus(PolicyStatus.DRAFT);
        policy.setCreatedAt(LocalDateTime.now());

        policy = policyRepo.save(policy);

        PolicyVersion version = new PolicyVersion();
        version.setPolicy(policy);
        version.setVersionNumber(1);
        version.setContent(request.getContent());
        version.setCreatedBy(owner);
        version.setCreatedAt(LocalDateTime.now());

        versionRepo.save(version);

        return policy;
    }

    // ================= SUBMIT FOR REVIEW =================
    public Policy submitForReview(Long policyId) {

        Policy policy = policyRepo.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found"));

        if (policy.getStatus() != PolicyStatus.DRAFT) {
            throw new RuntimeException("Only DRAFT policies can be submitted");
        }

        policy.setStatus(PolicyStatus.IN_REVIEW);
        return policyRepo.save(policy);
    }

    // ================= APPROVE POLICY =================
    public Policy approvePolicy(
            Long policyId,
            ApprovalRequest request,
            String approverUsername
    ) {

        Policy policy = policyRepo.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found"));

        if (policy.getStatus() != PolicyStatus.IN_REVIEW) {
            throw new RuntimeException("Policy not in review");
        }

        User approver = userRepo.findByUsername(approverUsername)
                .orElseThrow(() -> new RuntimeException("Approver not found"));

        PolicyVersion latestVersion =
        	    versionRepo.findByPolicyIdOrderByVersionNumberDesc(policyId)
        	        .stream()
        	        .findFirst()
        	        .orElseThrow(() ->
        	            new RuntimeException("No policy version found for policy " + policyId)
        	        );


        Approval approval = new Approval();
        approval.setPolicyVersion(latestVersion);
        approval.setApprover(approver);
        approval.setDecision(ApprovalDecision.APPROVED);
        approval.setComment(request.getComment());
        approval.setDecisionAt(LocalDateTime.now());

        approvalRepo.save(approval);

        policy.setStatus(PolicyStatus.APPROVED);
        return policyRepo.save(policy);
    }

    // ================= REJECT POLICY =================
    public Policy rejectPolicy(
            Long policyId,
            ApprovalRequest request,
            String approverUsername
    ) {

        Policy policy = policyRepo.findById(policyId)
                .orElseThrow(() -> new RuntimeException("Policy not found"));

        if (policy.getStatus() != PolicyStatus.IN_REVIEW) {
            throw new RuntimeException("Policy not in review");
        }

        User approver = userRepo.findByUsername(approverUsername)
                .orElseThrow(() -> new RuntimeException("Approver not found"));

        PolicyVersion latestVersion =
        	    versionRepo.findByPolicyIdOrderByVersionNumberDesc(policyId)
        	        .stream()
        	        .findFirst()
        	        .orElseThrow(() ->
        	            new RuntimeException("No policy version found for policy " + policyId)
        	        );


        Approval approval = new Approval();
        approval.setPolicyVersion(latestVersion);
        approval.setApprover(approver);
        approval.setDecision(ApprovalDecision.REJECTED);

        // ✅ SAFE HANDLING (THIS FIXES 500)
        if (request != null && request.getComment() != null) {
            approval.setComment(request.getComment());
        } else {
            approval.setComment("Rejected");
        }

        approval.setDecisionAt(LocalDateTime.now());
        approvalRepo.save(approval);

        policy.setStatus(PolicyStatus.DRAFT);
        return policyRepo.save(policy);
    }
    public List<Policy> getAllPolicies() {
        return policyRepo.findAll();
    }
    public List<ApprovalHistoryResponse> getApprovalHistory(Long policyId) {

        return approvalRepo
                .findByPolicyVersion_Policy_IdOrderByDecisionAtDesc(policyId)
                .stream()
                .map(a -> new ApprovalHistoryResponse(
                        a.getApprover().getUsername(),
                        a.getDecision(),
                        a.getComment(),
                        a.getDecisionAt(),
                        a.getPolicyVersion().getVersionNumber()
                ))
                .collect(Collectors.toList());
    }

}
