package com.policypulse.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "acknowledgements")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Acknowledgement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "policy_id")
    private Policy policy;

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private User employee;

    private LocalDateTime acknowledgedAt;
}
