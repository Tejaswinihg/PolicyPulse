package com.policypulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PolicyPluseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicyPluseApplication.class, args);
	}

}
