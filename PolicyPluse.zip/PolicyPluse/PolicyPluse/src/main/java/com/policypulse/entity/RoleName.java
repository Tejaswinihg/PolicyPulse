package com.policypulse.entity;

public enum RoleName {
    ADMIN,
    POLICY_OWNER,
    APPROVER,
    EMPLOYEE
}
