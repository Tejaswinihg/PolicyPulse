package com.policypulse.entity;

public enum ApprovalDecision {
    APPROVED,
    REJECTED
}
