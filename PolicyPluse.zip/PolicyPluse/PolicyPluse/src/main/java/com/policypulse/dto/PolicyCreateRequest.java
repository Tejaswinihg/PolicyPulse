package com.policypulse.dto;

public class PolicyCreateRequest {

    private String title;
    private String content;
    private Long departmentId;

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public Long getDepartmentId() {
        return departmentId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setDepartmentId(Long departmentId) {
        this.departmentId = departmentId;
    }
}
