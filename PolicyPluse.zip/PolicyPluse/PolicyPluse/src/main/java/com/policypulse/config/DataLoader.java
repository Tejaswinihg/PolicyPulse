package com.policypulse.config;

import com.policypulse.entity.*;
import com.policypulse.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Set;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner loadData(
            RoleRepository roleRepo,
            UserRepository userRepo,
            DepartmentRepository deptRepo,
            PasswordEncoder encoder
    ) {
        return args -> {

            if (roleRepo.count() == 0) {

                Role adminRole = roleRepo.save(new Role(RoleName.ADMIN));
                Role ownerRole = roleRepo.save(new Role(RoleName.POLICY_OWNER));
                Role approverRole = roleRepo.save(new Role(RoleName.APPROVER));
                Role empRole = roleRepo.save(new Role(RoleName.EMPLOYEE));

                Department it = deptRepo.save(
                        new Department("IT", "IT Department"));

                User admin = new User();
                admin.setUsername("admin");
                admin.setEmail("admin@company.com");
                admin.setPassword(encoder.encode("admin123"));
                admin.setEnabled(true);
                admin.setDepartment(it);
                admin.setRoles(Set.of(adminRole));
                userRepo.save(admin);

                User employee = new User();
                employee.setUsername("employee");
                employee.setEmail("employee@company.com");
                employee.setPassword(encoder.encode("emp123"));
                employee.setEnabled(true);
                employee.setDepartment(it);
                employee.setRoles(Set.of(empRole));
                userRepo.save(employee);
            }
        };
    }
}
