package com.policypulse.dto;

import com.policypulse.entity.ApprovalDecision;
import java.time.LocalDateTime;

public class ApprovalHistoryResponse {

    private String approverUsername;
    private ApprovalDecision decision;
    private String comment;
    private LocalDateTime decisionAt;
    private int versionNumber;

    public ApprovalHistoryResponse(
            String approverUsername,
            ApprovalDecision decision,
            String comment,
            LocalDateTime decisionAt,
            int versionNumber
    ) {
        this.approverUsername = approverUsername;
        this.decision = decision;
        this.comment = comment;
        this.decisionAt = decisionAt;
        this.versionNumber = versionNumber;
    }

    public String getApproverUsername() {
        return approverUsername;
    }

    public ApprovalDecision getDecision() {
        return decision;
    }

    public String getComment() {
        return comment;
    }

    public LocalDateTime getDecisionAt() {
        return decisionAt;
    }

    public int getVersionNumber() {
        return versionNumber;
    }
}
