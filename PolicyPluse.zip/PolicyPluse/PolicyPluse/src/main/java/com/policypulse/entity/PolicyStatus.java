package com.policypulse.entity;

public enum PolicyStatus {
    DRAFT,
    IN_REVIEW,
    APPROVED,
    PUBLISHED,
    ARCHIVED
}
